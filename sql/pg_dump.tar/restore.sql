--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.fiocar DROP CONSTRAINT fiocar_idfio_fkey;
ALTER TABLE ONLY public.fiocar DROP CONSTRAINT fiocar_idcar_fkey;
ALTER TABLE ONLY public.fio DROP CONSTRAINT fio_city_fkey;
ALTER TABLE ONLY public.fiocar DROP CONSTRAINT fiocar_pkey;
ALTER TABLE ONLY public.fio DROP CONSTRAINT fio_pkey;
ALTER TABLE ONLY public.city DROP CONSTRAINT city_pkey;
ALTER TABLE ONLY public.car DROP CONSTRAINT car_pkey;
DROP TABLE public.fiocar;
DROP TABLE public.fio;
DROP TABLE public.city;
DROP TABLE public.car;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: car; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE car (
    id integer NOT NULL,
    model character(50),
    nomer character(9),
    marka character varying(50)
);


ALTER TABLE car OWNER TO postgres;

--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE city (
    id integer NOT NULL,
    name character(150)
);


ALTER TABLE city OWNER TO postgres;

--
-- Name: fio; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fio (
    id integer NOT NULL,
    family character(100),
    name character(100),
    lastname character(100),
    idcity integer NOT NULL
);


ALTER TABLE fio OWNER TO postgres;

--
-- Name: fiocar; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fiocar (
    id integer NOT NULL,
    idfio integer NOT NULL,
    idcar integer NOT NULL
);


ALTER TABLE fiocar OWNER TO postgres;

--
-- Data for Name: car; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY car (id, model, nomer, marka) FROM stdin;
\.
COPY car (id, model, nomer, marka) FROM '$$PATH$$/2011.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY city (id, name) FROM stdin;
\.
COPY city (id, name) FROM '$$PATH$$/2012.dat';

--
-- Data for Name: fio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fio (id, family, name, lastname, idcity) FROM stdin;
\.
COPY fio (id, family, name, lastname, idcity) FROM '$$PATH$$/2013.dat';

--
-- Data for Name: fiocar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fiocar (id, idfio, idcar) FROM stdin;
\.
COPY fiocar (id, idfio, idcar) FROM '$$PATH$$/2014.dat';

--
-- Name: car_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY car
    ADD CONSTRAINT car_pkey PRIMARY KEY (id);


--
-- Name: city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY city
    ADD CONSTRAINT city_pkey PRIMARY KEY (id);


--
-- Name: fio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fio
    ADD CONSTRAINT fio_pkey PRIMARY KEY (id);


--
-- Name: fiocar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fiocar
    ADD CONSTRAINT fiocar_pkey PRIMARY KEY (id);


--
-- Name: fio_city_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fio
    ADD CONSTRAINT fio_city_fkey FOREIGN KEY (idcity) REFERENCES city(id);


--
-- Name: fiocar_idcar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fiocar
    ADD CONSTRAINT fiocar_idcar_fkey FOREIGN KEY (idcar) REFERENCES car(id);


--
-- Name: fiocar_idfio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fiocar
    ADD CONSTRAINT fiocar_idfio_fkey FOREIGN KEY (idfio) REFERENCES fio(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

